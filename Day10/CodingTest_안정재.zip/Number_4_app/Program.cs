﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Number_4_app
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}

/*
 4. 다음과 같은 결과를 나타내는 C# 코드를 구현하시오.
(구현여부를 선택하세요.  Key와 Value의 쌍으로 나오는 자료구조를 사용하세요)

출력값 :
무지개 색은 빨간색, 주황색, 노란색, 초록색, 파란색, 남색, 보라색, 입니다.

Key와 Value 확인
Purple은 보라색입니다.
 */
